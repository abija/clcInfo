-- You can use this type of code to prevent loading for other classes.
-- local _, class = UnitClass("player")
-- if class ~= "PALADIN" then return end

-- make sure clcInfo is loaded
if not clcInfo then return end

-- settings that are saved between session
-- there are 2 tables available for storage, one that is char specific and another one template specific

-- default values for char settings
local db_default = {
	char_var = false,
}

-- default values for template settings
local tdb_default = {
	template_var = false,
}

-- chose a name for your module
-- try not to use a common one like "retribution" since it could be easy to overwrite
-- module name needs to be in lowercase
local modName = "example module"

-- create a module in the main addon
local mod = clcInfo:RegisterClassModule(modName)

-- the functions visible in behavior code should be attached to this table
local emod = clcInfo.env

local db, tdb

-- this function, if it exists, will be called at init
-- good place to initalize char based settings
function mod.OnInitialize()
	print("Example module loaded")
	
	db = clcInfo:RegisterClassModuleDB(modName, db_default)
end

-- this function, if it exists, will be called when a template is loaded
-- good place to initalize template based settings
function mod.OnTemplatesUpdate()
	print("Template changed")
	
	tdb = clcInfo:RegisterClassModuleTDB(modName, tdb_default)
end

-- this is an example function that can be used into a behavior code box
function emod.IconExample()
	print(GetTime(), db.char_var, tdb.template_var)
end

-- if you display 2 icons, you might want to have icon1 handle the update for icon2 
-- in this case you need to disable the automatic update for icon2 and call it from icon1

-- link to the display element
local i2
-- function that replaces the update
local function I2Exec()
	print(GetTime(), "icon2")
end
-- function to cleanup the changes, it will be called when behavior code for icon2 changes
local function ExecCleanup()
	i2 = nil
end

-- first function
function emod.IconExample1()
	-- does it's own code
	print(GetTime(), "icon1")
	-- if it should update icon2 calls it's DoUpdate function
	if i2 then i2:DoUpdate() end
end

-- second function
-- first time it is called, removes the automatic update and saves the info required for manual update
function emod.IconExample2()
	-- save a link to the object
	i2 = emod.___e
	-- disable automatic update
	i2:SetScript("OnUpdate", nil)
	-- replaces the behavior code with the one in I2Exec
	i2.exec = I2Exec
	-- attaches the cleanup function
	i2.ExecCleanup = ExecCleanup
end

