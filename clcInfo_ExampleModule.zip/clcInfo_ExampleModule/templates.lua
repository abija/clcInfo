-- same as with the options, add this in a loader function
clcInfo.optionsCMLoaders[#(clcInfo.optionsCMLoaders) + 1] = function()
	local mod = clcInfo_Options.templates
	local defs = mod.defs
	mod:Add("icons", defs.CLASS, "Example", [[print("template example")]])
end