-- You can use this type of code to prevent loading for other classes.
-- local _, class = UnitClass("player")
-- if class ~= "PALADIN" then return end

-- make sure clcInfo is loaded
if not clcInfo then return end

-- clcInfo_Options is loaded on demand so won't be available when this addon loads
-- this means you'll have to do the initalization in a function
local mod, options, baseMod, db, tdb

-- needs to be lower case
local modName = "example module"

-- get and set functions
-- [[ typical info:
-- 1 class modules
-- 2 example module
-- 3 example tab
-- 4 group name
-- 5 var name
--]]
local function GetDB(info)
	return db[info[5]]
end
local function SetDB(info, val)
	db[info[5]] = val
end

local function GetTDB(info)
	return tdb[info[5]]
end
local function SetTDB(info, val)
	tdb[info[5]] = val
end

-- function to load when clcInfo_Options is loaded
local function LoadModule()
	-- initialize the variables
	mod = clcInfo_Options
	options = mod.options
	baseMod = clcInfo.classModules[modName]
	db = clcInfo:RegisterClassModuleDB(modName)
	tdb = clcInfo:RegisterClassModuleTDB(modName)
	
	-- add some simple toggle checkboxes
	options.args.classModules.args[modName] = {
		-- this is the name that will be displayed under class modules in the addon
		type = "group", childGroups = "tab", name = "Example Class Module",
		args = {
			tabChar = {
				order = 1, type = "group", name = "Char settings",
				args = {
					box1 = {
						order = 1, type = "group", inline = true, name = "Example char var",
						args = {
							char_var = {
								type = "toggle", name = "Char var",
								get = GetDB, set = SetDB,
							},
						},
					},
				},
			},
			tabTemplate = {
				order = 2, type = "group", name = "Template settings",
				args = {
					box1 = {
						order = 1, type = "group", inline = true, name = "Example template var",
						args = {
							template_var = {
								type = "toggle", name = "Template var",
								get = GetTDB, set = SetTDB,
							},
						},
					},
				},
			},
		},
	}
end

-- function needs to be added to a clcInfo table, that stores the functions to be called when Options are loaded
clcInfo.optionsCMLoaders[#(clcInfo.optionsCMLoaders) + 1] = LoadModule